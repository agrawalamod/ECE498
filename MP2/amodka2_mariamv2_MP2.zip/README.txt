Group members: Amod Agrawal (amodka2) & Mariam Vardishvili (mariamv2).

Amod walked for the experiment:
1) Step size: 1.5ft
2) Number of steps (/10secs): 14

